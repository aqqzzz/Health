<?php
/**
 * @version: 2015-12-01
 * @author: cylong
 * 数据库的配置
 */
define('DB_NAME', './data/health.db');
?>
