﻿# Health
面向 Web 的计算课程设计：健康专家系统

1. 首页为public_html/index.php 但是设置了session 会跳转到login.php界面
2. 使用了smarty模板，将php和html全部分开
3. 管理员账户为admin，密码为admin；医生账户为doc_id，密码doc_pass；教练账户为coa_id，密码coa_pass
4. 使用apache 为服务器，内置的sqlite3数据库
